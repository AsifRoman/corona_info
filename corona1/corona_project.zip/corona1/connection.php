<?php

$server="localhost";
$user="root";
$password="";
$db="corona_contact";

$con=mysqli_connect($server, $user, $password, $db);

	

?>