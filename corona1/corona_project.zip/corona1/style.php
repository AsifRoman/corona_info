<style type="text/css">


	html{
		scroll-behavior: smooth;
	}
	
	*{
	 margin: 0;
	 padding: 0; 
	 box-sizing: border-box; 
	 font-family: 'Muli', sans-serif;	 
	}

 	.nav_style {
	background: #833ab4;  /* fallback for old browsers */
	background: -webkit-linear-gradient(to right, #fcb045, #fd1d1d, #833ab4);  /* Chrome 10-25, Safari 5.1-6 */
	background: linear-gradient(to right, #fcb045, #fd1d1d, #833ab4)!important;; /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
	}
	.nav_style a {
	  color: white;
	  font-size: 20px;
	}
	h2:hover {
    color: blue;
    transition: 0.5s;
	}
	p:hover {
    color: blue;
    transition: 0.5s;
	}

	   /*////////// main-header ////*/
	#main {
	   	background-color: ;
	}
	.covid {
	  color: #061161;
	  margin-left: 0px;
	  font-weight: bold;
	}
	.main-header{
	  height: 450px;
	  width:100%;
	  margin-top: 60px;
	}
	.main-styling {
	   	text-align: center;
	   	font-family: 'Dancing Script', cursive;
	   	color: lime;
	   	font-weight: bold;
	}
	.tweet {
		text-align: center;
		font-weight: bold;
	}
	.rightside h1{
	  font-size: 4rem;
	}
	.corona_rot img{
	   	animation: gocorona 3s linear infinite;
	   	width:50px;
	   	height:50px;
	}

	@keyframes gocorona{
	   	0%{
	   		transform: rotate(0);
	   	}
	   	100% {
	   		transform: rotate(360deg);
	   	}
	   }
	.leftside img{
		animation: heartbeat 5s linear infinite;
	}
	@keyframes heartbeat
	   {
	   	0%
	   	{
	   		transform: scale(.75);
	   	}
	   	20%
	   	{
	   		transform: scale(1);
	   	}
	   	40%
	   	{
	   		transform: scale(.75);
	   	}
	   	60%
	   	{
	   		transform: scale(1);
	   	}
	   	80%
	   	{
	   		transform: scale(.75);
	   	}
	   	100%
	   	{
	   		transform: scale(.75);
	   	}
	   
	}	


	   /*////////// corona update //////*/
	.corona_update{
	   	margin:0 0 20px 0; 
	   /*	background-color: green;*/

	}
 		/*.count{
 			float:left;
 		}*/

	.corona_update h3{
	   	 color:#ff7675;
	}
	.corona_update h1{
	   	 font-size: 2rem; text-align: center;
	}
	.corona_update p{
	   	 font-size: 1rem; 
	}


	   /*////////// about section //////*/
	#aboutid {
	   	background-color: #a8ff78;
	    margin:0 0 20px 0; 
	}
	#mythid {
		margin:0 0 20px 0; 
		background-color: #00b09b;
	}
	}
	#sympid {
		margin:0 0 20px 0; 
		background-color: #F37335;
	}
	#preventid {
		background-color: #dd3e54;
		margin:0 0 20px 0; 	
	}
	#contactid {
		margin:0 0 20px 0; 
		background: #00F260;  /* fallback for old browsers */
		background: -webkit-linear-gradient(to right, #0575E6, #00F260);  /* Chrome 10-25, Safari 5.1-6 */
		background: linear-gradient(to right, #0575E6, #00F260); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

	}
		
	    /*//////////footer //////*/

	footer.page-footer {
	    bottom: 0;
	    color: #fff;
	}
	.page-footer {
	    background-color: #1C2331;
	}
	.font-small {
	    font-size: .9rem;
	}
	.fx {
		margin:0 0 20px 0; 
		width: 200px; 
		height: 200px ;
		border-radius: 50%;
	}

			/* End Footer */

/*//////////top scroll //////*/
    #myBtn {
	    	
	    	position: fixed;
	    	bottom: 40px;
	    	right: 40px;
	    	z-index: 99;
	    	border: none;
	    	outline: none;
	    	background-color: #00ABFF;
	    	color: white;
	    	cursor: pointer;
	    	padding: 10px;
	    	border-radius: 10px;
	}
	#myBtn:hover {
	    	background: #606060;
	}

	    /*///////// responsive/////////*/



	@media(max-width:760px){

	    	.main-header{ height: 700px; text-align: center; }
	    	.main-header h1{ text-align: center;padding: 0; width:100%; font-size: 30px; }
	    	.covid{ margin-left: -40px; }
	}

	    

</style>
